# Sim01

COMPILE: Compile the program using the command 'make'. To clear and remake use 'make clean'.

LIBRARIES: No special libraries were used for this assignment. Everything used are the typical
cstdlib, iostream, fstream.
